"""Butler Discord bot package."""
